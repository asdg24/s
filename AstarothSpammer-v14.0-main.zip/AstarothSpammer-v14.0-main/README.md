# AstarothSpammer-v14.0
Leaked Version And Works Amazingly!
Run The Exe which contains (Runthis) 
It should open the spammer tool, enter your 2caotcha key in settings and start generating comrades!
